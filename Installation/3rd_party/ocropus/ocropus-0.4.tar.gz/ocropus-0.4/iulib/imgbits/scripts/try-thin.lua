dinit(700,700)

bi = bits.readnew("image.png")
bits.dshow(bi,"")
bits.thin(bi,-1);
bits.dshow(bi,"")
dwait()
